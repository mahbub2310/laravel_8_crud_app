<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Crud;
use Session;

class CrudController extends Controller
{
    public function showData(){
        // $showData = Crud::all();
        // $showData = Crud::paginate(5);
        $showData = Crud::simplePaginate(5);
        return View('show_data', compact('showData'));
    }

    public function addData(){
        return View('add_data');
    }

    public function storeData(Request $request){
        $rules = [
            'name'=>'required|max:20',
            'email'=>'required|email',
        ];
        $cm = [
            'name.required'=>'Enter Your Name',
            'name.max'=>'Name can not more than 20 char',
            'email.required'=>'Enter Your Email',
            'email.email'=>'Email must be a valid!',

        ];
        $this->validate($request, $rules,$cm);

        $crud = new Crud();
        $crud->name = $request->name;
        $crud->email = $request->email;
        $crud->save();
        Session::flash('msg','Data Successfully Added');

        return redirect('/');
    }

    public function editData($id=null){
        $editData = Crud::find($id);
        return View('edit_data',compact('editData'));
    }

    public function updateData(Request $request,$id){
        $rules = [
            'name'=>'required|max:20',
            'email'=>'required|email',
        ];
        $cm = [
            'name.required'=>'Enter Your Name',
            'name.max'=>'Name can not more than 20 char',
            'email.required'=>'Enter Your Email',
            'email.email'=>'Email must be a valid!',

        ];
        $this->validate($request, $rules,$cm);

        $crud = Crud::find($id);
        $crud->name = $request->name;
        $crud->email = $request->email;
        $crud->save();
        Session::flash('msg','Data Successfully Updated');
        return redirect('/');
    }

    public function deleteData($id=null){
        $deleteData = Crud::find($id);
        $deleteData->delete();
        Session::flash('msg','Data Successfully Updated');
        return redirect('/');


    }

}
